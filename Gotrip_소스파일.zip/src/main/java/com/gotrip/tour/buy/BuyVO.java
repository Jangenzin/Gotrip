package com.gotrip.tour.buy;

public class BuyVO {
	private int buy_no;
	private int buy_date;
	private String buy_pay;
	private int pro_no;
	private int mem_no;
	
	public BuyVO() {}
	
	public BuyVO(int buy_no, int buy_date, String buy_pay, int pro_no, int mem_no) {
		super();
		this.buy_no = buy_no;
		this.buy_date = buy_date;
		this.buy_pay = buy_pay;
		this.pro_no = pro_no;
		this.mem_no = mem_no;
	}
	
	public int getBuy_no() {
		return buy_no;
	}

	public void setBuy_no(int buy_no) {
		this.buy_no = buy_no;
	}

	public int getBuy_date() {
		return buy_date;
	}

	public void setBuy_date(int buy_date) {
		this.buy_date = buy_date;
	}

	public String getBuy_pay() {
		return buy_pay;
	}

	public void setBuy_pay(String buy_pay) {
		this.buy_pay = buy_pay;
	}

	public int getPro_no() {
		return pro_no;
	}

	public void setPro_no(int pro_no) {
		this.pro_no = pro_no;
	}

	public int getMem_no() {
		return mem_no;
	}

	public void setMem_no(int mem_no) {
		this.mem_no = mem_no;
	}

	@Override
	public String toString() {
		return "BuyDto [buy_no=" + buy_no + ", buy_date=" + buy_date + ", buy_pay=" + buy_pay + ", pro_no=" + pro_no
				+ ", mem_no=" + mem_no + "]";
	}
}
