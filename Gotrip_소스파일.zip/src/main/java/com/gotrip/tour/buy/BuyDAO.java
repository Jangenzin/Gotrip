package com.gotrip.tour.buy;

public interface BuyDAO {

}
