package com.gotrip.tour.buy;

public class BuyController {

}
