package com.gotrip.tour.image;


//이미지는 다른테이블로 끌어다 쓰므로 사용 안 할 가능성 있음 
//어떻게 될지 모르니 일단 만들어둠 
public interface TimgDAO {

}
