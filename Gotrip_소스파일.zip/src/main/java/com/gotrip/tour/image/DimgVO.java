package com.gotrip.tour.image;

public class DimgVO {
	private int dimg_no ;
	private String  dimg_name ;
	
	public int getDimg_no() {
		return dimg_no;
	}
	public void setDimg_no(int dimg_no) {
		this.dimg_no = dimg_no;
	}
	public String getDimg_name() {
		return dimg_name;
	}
	public void setDimg_name(String dimg_name) {
		this.dimg_name = dimg_name;
	}
}
