package com.gotrip.tour.image;

public class TimgVO {
	private int timg_no ;
	private String timg_name;
	public int getTimg_no() {
		return timg_no;
	}
	public void setTimg_no(int timg_no) {
		this.timg_no = timg_no;
	}
	public String getTimg_name() {
		return timg_name;
	}
	public void setTimg_name(String timg_name) {
		this.timg_name = timg_name;
	}  
}
