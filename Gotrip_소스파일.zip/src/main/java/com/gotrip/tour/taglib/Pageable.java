package com.gotrip.tour.taglib;

public class Pageable {
    public int page = 1;
    
    public int listSize = 10;

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getListSize() {
        return listSize;
    }

    public void setListSize(int listSize) {
        this.listSize = listSize;
    }
    
    public int skipCount() {
        return (page - 1) * listSize;
    }
}
