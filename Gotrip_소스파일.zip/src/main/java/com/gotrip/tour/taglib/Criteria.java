package com.gotrip.tour.taglib;

import org.apache.ibatis.session.RowBounds;

public class Criteria extends Pageable {
	
	// 향후 검색 대상필드 추가 
	
	public RowBounds getRowBounds() {
    	return new RowBounds(skipCount(), listSize);
    }
}
