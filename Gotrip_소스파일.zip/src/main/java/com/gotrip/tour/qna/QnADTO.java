package com.gotrip.tour.qna;

public class QnADTO {
	private int qna_no;
	private String qna_title;
	private String qna_detail;
	private String qna_date;
	private String qna_answer;
	
	private int mem_no;
	private String mem_name;
	private String mem_id;
	private String mem_type;
	
	
	
	
	
	public String getMem_type() {
		return mem_type;
	}

	public void setMem_type(String mem_type) {
		this.mem_type = mem_type;
	}

	public String getMem_name() {
		return mem_name;
	}

	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public QnADTO() {}

	public QnADTO(int qna_no, String qna_title, String qna_detail, String qna_date, String qna_answer, int mem_no) {
		super();
		this.qna_no = qna_no;
		this.qna_title = qna_title;
		this.qna_detail = qna_detail;
		this.qna_date = qna_date;
		this.qna_answer = qna_answer;
		this.mem_no = mem_no;
	}

	public int getQna_no() {
		return qna_no;
	}

	public void setQna_no(int qna_no) {
		this.qna_no = qna_no;
	}

	public String getQna_title() {
		return qna_title;
	}

	public void setQna_title(String qna_title) {
		this.qna_title = qna_title;
	}

	public String getQna_detail() {
		return qna_detail;
	}

	public void setQna_detail(String qna_detail) {
		this.qna_detail = qna_detail;
	}

	public String getQna_date() {
		return qna_date;
	}

	public void setQna_date(String qna_date) {
		this.qna_date = qna_date;
	}

	public String getQna_answer() {
		return qna_answer;
	}

	public void setQna_answer(String qna_answer) {
		this.qna_answer = qna_answer;
	}

	public int getMem_no() {
		return mem_no;
	}

	public void setMem_no(int mem_no) {
		this.mem_no = mem_no;
	}

	@Override
	public String toString() {
		return "QnADto [qna_no=" + qna_no + ", qna_title=" + qna_title + ", qna_detail=" + qna_detail + ", qna_date="
				+ qna_date + ", qna_answer=" + qna_answer + ", mem_no=" + mem_no + "]";
	}
}
