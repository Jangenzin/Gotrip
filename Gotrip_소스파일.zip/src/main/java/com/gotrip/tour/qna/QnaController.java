package com.gotrip.tour.qna;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.gotrip.tour.taglib.Criteria;
import com.gotrip.tour.taglib.PageHolder;

@Controller
public class QnaController {
	@Autowired
	SqlSession sqlSession;

	@RequestMapping(value = "/qna/write")
	public ModelAndView qnaWrite(HttpServletRequest req) {

		QnaDAO qnaDAO = sqlSession.getMapper(QnaDAO.class);
		HttpSession session = req.getSession();
		String logid = (String) session.getAttribute("logid");

		ModelAndView mav = new ModelAndView();
		if ("null".equals(String.valueOf(logid))) {
			mav.setViewName("redirect:../member/loginForm");
		} else {

			String mem_no = qnaDAO.getMem_no(logid);
			mav.addObject("mem_no", mem_no);
			mav.addObject("logid", logid);
			mav.addObject("mode", "write");
			mav.setViewName("qna/detail");
		}
		return mav;
	}

	@RequestMapping(value = "/qna/add", method = RequestMethod.POST)
	public ModelAndView qnaAdd(QnADTO qnADTO) {

		QnaDAO qnaDAO = sqlSession.getMapper(QnaDAO.class);
		qnaDAO.add(qnADTO);

		ModelAndView mav = new ModelAndView();

		mav.setViewName("redirect:list");
		return mav;
	}

	@RequestMapping(value = "/qna/update", method = RequestMethod.POST)
	public ModelAndView qnaUpdate(QnADTO qnADTO) {

		QnaDAO qnaDAO = sqlSession.getMapper(QnaDAO.class);
		System.out.println("[answer]" + qnADTO.getQna_answer());
		
		qnaDAO.update(qnADTO);

		ModelAndView mav = new ModelAndView();

		mav.setViewName("redirect:list");
		return mav;
	}
	
	@RequestMapping(value = "/qna/delete", method = RequestMethod.GET)
	public ModelAndView qnaDelete(@RequestParam int no) {

		System.out.println("del:" + no);
		
		QnaDAO qnaDAO = sqlSession.getMapper(QnaDAO.class);
		qnaDAO.delete(no);

		ModelAndView mav = new ModelAndView();

		mav.setViewName("redirect:list");
		return mav;
	}

	@RequestMapping(value = "/qna/list")
	public ModelAndView qnaList(HttpServletRequest req,Criteria criteria) {
		HttpSession session = req.getSession();

		System.out.println("[SessionID]" + session.getAttribute("logid"));

		QnaDAO qnaDAO = sqlSession.getMapper(QnaDAO.class);
		int rowCount = qnaDAO.getRowCnt(criteria);
		PageHolder pageHolder = new PageHolder(rowCount, criteria.getPage(), criteria.getListSize());
		
		List<QnADTO> list = qnaDAO.list(criteria.getRowBounds());
		
		ModelAndView mav = new ModelAndView();

		mav.addObject("pageHolder", pageHolder);
		mav.addObject("list", list);
		mav.setViewName("qna/list");

		return mav;
	}

	@RequestMapping(value = "/qna/detail")
	public ModelAndView qnaDetail(@RequestParam int no) {

		QnaDAO qnaDAO = sqlSession.getMapper(QnaDAO.class);
		QnADTO qnADTO = qnaDAO.getView(no);
		System.out.println("qnaDTO:" + qnADTO.getMem_type());
		ModelAndView mav = new ModelAndView();

		mav.addObject("mode", "detail");
		mav.addObject("qnADTO", qnADTO);
		mav.setViewName("qna/detail");
		return mav;
	}

}
