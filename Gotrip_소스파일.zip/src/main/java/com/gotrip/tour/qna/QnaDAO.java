package com.gotrip.tour.qna;

import java.util.List;

import org.apache.ibatis.session.RowBounds;

import com.gotrip.tour.taglib.Criteria;

public interface QnaDAO {

	public List<QnADTO> list(RowBounds rowBounds);
	public QnADTO getView(int no);
	public void add(QnADTO qnADTO);
	public String getMem_no(String logid);
	public void update(QnADTO qnADTO);
	public void delete(int no);
	public int getRowCnt(Criteria criteria);
}
