package com.gotrip.tour;

public interface HomeDAO {

}
