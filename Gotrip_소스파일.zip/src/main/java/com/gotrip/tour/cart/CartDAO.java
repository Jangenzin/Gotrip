package com.gotrip.tour.cart;

public interface CartDAO {

}
