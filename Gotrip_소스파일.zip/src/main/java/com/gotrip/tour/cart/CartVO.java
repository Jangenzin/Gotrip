package com.gotrip.tour.cart;

public class CartVO {
	private int cart_no;
	private int buy_no;
	private int cart_date;
	
	public CartVO() {}

	public CartVO(int cart_no, int buy_no, int cart_date) {
		super();
		this.cart_no = cart_no;
		this.buy_no = buy_no;
		this.cart_date = cart_date;
	}

	public int getCart_no() {
		return cart_no;
	}

	public void setCart_no(int cart_no) {
		this.cart_no = cart_no;
	}

	public int getBuy_no() {
		return buy_no;
	}

	public void setBuy_no(int buy_no) {
		this.buy_no = buy_no;
	}

	public int getCart_date() {
		return cart_date;
	}

	public void setCart_date(int cart_date) {
		this.cart_date = cart_date;
	}

	@Override
	public String toString() {
		return "CartDto [cart_no=" + cart_no + ", buy_no=" + buy_no + ", cart_date=" + cart_date + "]";
	}
}
