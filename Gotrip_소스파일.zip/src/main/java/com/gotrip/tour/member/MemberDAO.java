package com.gotrip.tour.member;

import java.util.List;

public interface MemberDAO {
	public int register(MemberVO vo); // 회원가입
	public MemberVO login(MemberVO vo); // 로그인
	public MemberVO idCheck(String id); // 아이디 중복확인
	public String findId(MemberVO vo); // 아이디 찾기
	public String findPw(MemberVO vo); // 비밀번호 찾기
	public int memberEdit(MemberVO vo); // 회원정보 수정
	public int memberDelete(MemberVO vo); // 회원탈퇴
}
