package com.gotrip.tour.member;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.gotrip.tour.qna.QnADTO;
import com.gotrip.tour.qna.QnaDAO;

@Controller
public class MemberController {
	@Autowired
	SqlSession sqlSession;
	
	// --> 회원가입 화면
	@RequestMapping(value = "/member/registerForm")
	public String memberRegisterForm() {
		
		return "member/registerForm";
	}
	
	// --> 회원가입
	@RequestMapping(value = "/member/register", method = RequestMethod.POST)
	public ModelAndView register(MemberVO vo) {
		
		MemberDAO dao = sqlSession.getMapper(MemberDAO.class);
		ModelAndView mav = new ModelAndView();
		try{
			int cnt = dao.register(vo);
			if(cnt > 0) {
				mav.setViewName("member/registerOK"); 
			} else {
				mav.setViewName("redirect:../member/registerForm");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return mav;
	}
	
	// --> 아이디 중복확인
	@ResponseBody
	@RequestMapping(value = "/member/idCheck", produces = "text/plain")
	public String idCheck(@RequestBody String paramData) {
		
		String inputId = paramData.trim();
		MemberDAO dao = sqlSession.getMapper(MemberDAO.class);
		MemberVO vo = dao.idCheck(inputId);
		
		if(vo != null) {
			return "-1";
		} else {
			return "0";
		}
	}
	
	// --> 로그인 화면
	@RequestMapping(value = "/member/loginForm")
	public String memberLoginForm() {
		
		return "member/loginForm";
	}
	
	// --> 로그인
	@RequestMapping(value = "/member/login")
	public ModelAndView login(MemberVO vo, HttpServletRequest req) {
		
		MemberDAO dao = sqlSession.getMapper(MemberDAO.class);
		MemberVO vo2 = dao.login(vo);
		ModelAndView mav = new ModelAndView();
		if(vo2 == null) {
			mav.setViewName("redirect:../member/loginForm");
		}else { 
			HttpSession session = req.getSession();
			session.setAttribute("logid", vo2.getMem_id());
			session.setAttribute("logname", vo2.getMem_name());
			session.setAttribute("loginfo", vo2);
			mav.setViewName("member/loginOK");
		}
		return mav;
	}
	
	// --> 아이디 찾기 화면
	@RequestMapping(value = "/member/findIdForm")
	public String memberFindIdForm() {
		
		return "member/findIdForm";
	}
	
	// --> 아이디 찾기
	@RequestMapping(value = "/member/findId", method = RequestMethod.POST)
	public ModelAndView findId(MemberVO vo) {
		
		MemberDAO dao = sqlSession.getMapper(MemberDAO.class);
		String id = dao.findId(vo);
		ModelAndView mav = new ModelAndView();
		if(id == null) {			
			mav.setViewName("member/findIdError");
		}else { 
			mav.addObject("id", id);
			mav.setViewName("member/findIdOK");
		}
		return mav;
	}
	
	// --> 비밀번호 찾기 화면
	@RequestMapping(value = "/member/findPwForm")
	public String memberFindPwForm() {
			
		return "member/findPwForm";
	}
	
	// --> 비밀번호 찾기
	@RequestMapping(value = "/member/findPw", method = RequestMethod.POST)
	public ModelAndView findPw(MemberVO vo) {
			
		MemberDAO dao = sqlSession.getMapper(MemberDAO.class);
		String pw = dao.findPw(vo);
		ModelAndView mav = new ModelAndView();
		if(pw == null) {			
			mav.setViewName("member/findPwError");
		}else { 
			mav.addObject("pw", pw);
			mav.setViewName("member/findPwOK");
		}
		return mav;
	}
	
	// --> 마이페이지 화면(회원정보 수정, 회원탈퇴 기능 구현 테스트 용 임시화면)
	@RequestMapping(value = "/member/myPage")
	public String myPage() {
				
		return "member/myPage";
	}
	
	// --> 회원정보 수정 화면
	@RequestMapping(value = "/member/editForm")
	public String memberEditForm() {
		
		return "member/editForm";
	}
	
	// --> 회원정보 수정
	@RequestMapping(value = "/member/edit", method = RequestMethod.POST)
	public ModelAndView memberEdit(MemberVO vo, HttpServletRequest req) {
		
		MemberDAO dao = sqlSession.getMapper(MemberDAO.class);
		ModelAndView mav = new ModelAndView();
		try{
			int cnt = dao.memberEdit(vo);			
			if(cnt > 0) {
				HttpSession session = req.getSession();
				session.setAttribute("loginfo", vo);
				mav.setViewName("member/editOK");
			} else {
				mav.setViewName("member/editError");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return mav;
	}
	
	// --> 회원탈퇴 화면
	@RequestMapping(value = "/member/deleteForm")
	public String memberdeleteForm() {
		
		return "member/deleteForm";
	}
	
	// --> 회원탈퇴
	@RequestMapping(value = "/member/delete")
	public ModelAndView memberdelete(MemberVO vo, HttpServletRequest req) {
		
		MemberDAO dao = sqlSession.getMapper(MemberDAO.class);
		ModelAndView mav = new ModelAndView();
		try{
			int cnt = dao.memberDelete(vo);			
			if(cnt > 0) {
				HttpSession session = req.getSession();
				session.invalidate();
				mav.setViewName("member/deleteOK");
			} else {
				mav.setViewName("member/deleteError");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return mav;
	}
	
	// --> 로그아웃
	@RequestMapping(value = "/member/logout")
	public String logout(HttpServletRequest req) {
		
		HttpSession session = req.getSession();
		session.invalidate();
		
		return "member/loginForm";
	}
}