package com.gotrip.tour.member;

public class MemberVO {
	private int mem_no;
	private String mem_id;
	private String mem_pw;
	private String mem_name;
	private int mem_tel;
	private String mem_email;
	private String mem_type;
	
	public MemberVO() {}
	
	public MemberVO(int mem_no, String mem_id, String mem_pw, String mem_name, int mem_tel, String mem_email,
			String mem_type) {
		super();
		this.mem_no = mem_no;
		this.mem_id = mem_id;
		this.mem_pw = mem_pw;
		this.mem_name = mem_name;
		this.mem_tel = mem_tel;
		this.mem_email = mem_email;
		this.mem_type = mem_type;
	}

	public int getMem_no() {
		return mem_no;
	}

	public void setMem_no(int mem_no) {
		this.mem_no = mem_no;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public String getMem_pw() {
		return mem_pw;
	}

	public void setMem_pw(String mem_pw) {
		this.mem_pw = mem_pw;
	}

	public String getMem_name() {
		return mem_name;
	}

	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}

	public int getMem_tel() {
		return mem_tel;
	}

	public void setMem_tel(int mem_tel) {
		this.mem_tel = mem_tel;
	}

	public String getMem_email() {
		return mem_email;
	}

	public void setMem_email(String mem_email) {
		this.mem_email = mem_email;
	}

	public String getMem_type() {
		return mem_type;
	}

	public void setMem_type(String mem_type) {
		this.mem_type = mem_type;
	}

	@Override
	public String toString() {
		return "MemberDto [mem_no=" + mem_no + ", mem_id=" + mem_id + ", mem_pw=" + mem_pw + ", mem_name=" + mem_name
				+ ", mem_tel=" + mem_tel + ", mem_email=" + mem_email + ", mem_type=" + mem_type + "]";
	}
}
