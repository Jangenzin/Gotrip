package com.gotrip.tour.review;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.gotrip.tour.image.TimgVO;
import com.gotrip.tour.member.MemberVO;
import com.gotrip.tour.product.ProductVO;

public interface ReviewDAO {
	
	public List<ReviewVO> reviewDetail(ReviewVO vo) throws Exception;
	//public List<ReviewVO> reviewDetail(Map<String, Object> pMap) throws Exception;

	public int reviewInsert(ReviewVO vo) throws Exception;

	public ReviewVO reviewSelect(int rev_no);
	
	public int reviewUpdate(ReviewVO vo) throws Exception;

	public int reviewDelete(ReviewVO vo) throws Exception;
	
	public List<ReviewVO> reviewList(ReviewVO vo) throws Exception;
	
	public int updatehit(int rev_no) throws Exception;
	
	public int insertImg(ImguploadVO vo);
	
	public int getNewRevNo(int mem_no);
	
	public ImguploadVO getFile(int rev_no);
	
	public int updateImg(ImguploadVO vo);
	
	public int deleteImg(int rev_no);
	
	public int reviewCount(int rev_vo);

}
