package com.gotrip.tour.review;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

//import com.gotrip.tour.member.MemberVO;
import com.gotrip.tour.review.ImguploadVO;
public class ReviewVO {
	private int rev_no;
	private String rev_title;
	private String rev_detail;
	private String rev_date;
	private int rev_hit;
	private int mem_no;
	private String mem_name;
	private int timg_no;
	private String timg_name;
	private int dimg_no;
	private String dimg_name;
	
	private int pageNum=1;
	private int onePageRecord=10;
	private int totalPage;
	private int totalRecord;
	private int startPage;
	private int onePageMax=10;
	
	private MultipartFile rev_img;
	private String image_url;
	
//	private String file_path;
//	private String file_name;
	
	private MultipartFile uploadFile;
private int reviewCount;

	public int getRev_no() {
		return rev_no;
	}

	public void setRev_no(int rev_no) {
		this.rev_no = rev_no;
	}

	public String getRev_title() {
		return rev_title;
	}

	public void setRev_title(String rev_title) {
		this.rev_title = rev_title;
	}

	public String getRev_detail() {
		return rev_detail;
	}

	public void setRev_detail(String rev_detail) {
		this.rev_detail = rev_detail;
	}

	public String getRev_date() {
		return rev_date;
	}

	public void setRev_date(String rev_date) {
		this.rev_date = rev_date;
	}

	public int getRev_hit() {
		return rev_hit;
	}

	public void setRev_hit(int rev_hit) {
		this.rev_hit = rev_hit;
	}

	public int getMem_no() {
		return mem_no;
	}

	public void setMem_no(int mem_no) {
		this.mem_no = mem_no;
	}

	public int getTimg_no() {
		return timg_no;
	}

	public void setTimg_no(int timg_no) {
		this.timg_no = timg_no;
	}

	public int getDimg_no() {
		return dimg_no;
	}

	public void setDimg_no(int dimg_no) {
		this.dimg_no = dimg_no;
	}

	public String getTimg_name() {
		return timg_name;
	}

	public void setTimg_name(String timg_name) {
		this.timg_name = timg_name;
	}

	public String getDimg_name() {
		return dimg_name;
	}

	public void setDimg_name(String dimg_name) {
		this.dimg_name = dimg_name;
	}

//	public String getFile_name() {
//		return file_name;
//	}
//
//	public void setFile_name(String file_name) {
//		this.file_name = file_name;
//	}
//
//	public String getFile_path() {
//		return file_path;
//	}
//
//	public void setFile_path(String file_path) {
//		this.file_path = file_path;
//	}

	public MultipartFile getUploadFile() {
		return uploadFile;
	}

	public void setUploadFile(MultipartFile uploadFile) {
		this.uploadFile = uploadFile;
	}

	public int getPageNum() {
		return pageNum;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	public int getOnePageRecord() {
		return onePageRecord;
	}

	public void setOnePageRecord(int onePageRecord) {
		this.onePageRecord = onePageRecord;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getTotalRecord() {
		return totalRecord;
	}

	public void setTotalRecord(int totalRecord) {
		this.totalRecord = totalRecord;
	}

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getOnePageMax() {
		return onePageMax;
	}

	public void setOnePageMax(int onePageMax) {
		this.onePageMax = onePageMax;
	}

	public int setReviewCount(int reviewCount) {
		return reviewCount;
		
	}

	public String getMem_name() {
		return mem_name;
	}

	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}

	public MultipartFile getRev_img() {
		return rev_img;
	}

	public void setRev_img(MultipartFile rev_img) {
		this.rev_img = rev_img;
	}

	public String getImage_url() {
		return image_url;
	}

	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}


}
