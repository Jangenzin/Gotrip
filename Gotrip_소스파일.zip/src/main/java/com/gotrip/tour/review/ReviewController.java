package com.gotrip.tour.review;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.gotrip.tour.image.TimgVO;
import com.gotrip.tour.review.ReviewDAO;
import com.gotrip.tour.review.ReviewVO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

@Controller
public class ReviewController {
//	http://localhost:9000/Gotrip/review/list
//	http://localhost:9000/Gotrip/member/loginForm	
//	public String path = null;
	@Autowired
	SqlSession sqlSession;
	
	@Resource(name = "uploadPath")
	private String uploadPath;
	
//	@GetMapping(value = "/review/list")
//	public ModelAndView view(ReviewVO Vo,HttpServletRequest req) throws Exception {
//		ReviewVO vo = new ReviewVO();
//		ReviewDAO dao = sqlSession.getMapper(ReviewDAO.class);
//		List<ReviewVO> lst = dao.reviewList(vo);
//		ModelAndView mav = new ModelAndView();
//		mav.addObject("vo", vo);
//		mav.addObject("lst", lst);
//		mav.setViewName("review/review");
//		System.out.println(lst);
//		System.out.println(vo);
//		return mav;
//	}
	
	@GetMapping(value = "/review/list")
	public ModelAndView view(@RequestParam Map<String, Object> pMap) {
		List<Map<String, Object>> lst = null;
		lst = sqlSession.selectList("getAllRevRecord", pMap);
		ModelAndView mav = new ModelAndView();
		mav.addObject("lst", lst);
		mav.setViewName("review/review");
		System.out.println(lst);
		return mav;
	}
	

//	@GetMapping(value = "/review/detail")
//	public ModelAndView view2(ReviewVO vo, @RequestParam("rev_no") int rev_no,
//			HttpServletRequest req) throws Exception {
//		System.out.println("reviewDetail rev_no??????????????"+rev_no);
//	//	List<Map<String, Object>> lst = null;
//		ReviewDAO dao = sqlSession.getMapper(ReviewDAO.class);
//		dao.updatehit(rev_no);
//		List<ReviewVO> lst = dao.reviewDetail(vo);
//		//lst = sqlSession.selectList("reviewDetail", pMap);
//		
//		path = req.getSession().getServletContext().getRealPath("/imgUpload");
//		ImguploadVO img = dao.getFile(rev_no);
//		String fileName = img.getFile_name();
//		int imgNo = img.getImg_no();
//		System.out.println("fileName?????????"+fileName);
//		System.out.println("imgNo?????????"+imgNo);
//		
//		ModelAndView mav = new ModelAndView();
//		mav.addObject("lst", lst);
//		mav.addObject("rev_no", rev_no);
//		if(fileName != null) {
//			mav.addObject("fileName", fileName);
//			mav.addObject("imgNo", imgNo);
//			mav.addObject("path", path);
//		}else {
//			mav.addObject("fileName", "");
//		}
//		mav.setViewName("review/reviewDetail");
//		return mav;
//	}
	
	private String uploadFile(String originalName, byte[] fileDate) throws IOException {

		UUID uid = UUID.randomUUID();

		String savedName = uid.toString() + "_" + originalName;
		File target = new File(uploadPath, savedName);

		// org.springframework.util 패키지의 FileCopyUtils는 파일 데이터를 파일로 처리하거나, 복사하는 등의 기능이
		// 있다.
		FileCopyUtils.copy(fileDate, target);

		return savedName;

	}
	
	@GetMapping(value = "/review/detail")
	public ModelAndView view2(@RequestParam Map<String, Object> pMap, @RequestParam("rev_no") int rev_no, ReviewVO vo,
			HttpServletRequest req) throws Exception {

		List<Map<String, Object>> lst = null;
		ReviewDAO dao = sqlSession.getMapper(ReviewDAO.class);
		lst = sqlSession.selectList("getAllRevRecord2", pMap);
		ModelAndView mav = new ModelAndView();
		mav.addObject("lst", lst);
		mav.addObject("rev_no", rev_no);
		mav.setViewName("review/reviewdetail");

		return mav;
	}
	
	@RequestMapping("/review/write")
	public ModelAndView board_writeForm() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("review/writeForm");

		return mav;
	}
	
//	@RequestMapping("/review/write")
//	public ModelAndView board_writeForm(HttpServletRequest req) throws Exception {
//		HttpSession session = req.getSession();
//		ReviewDAO dao = sqlSession.getMapper(ReviewDAO.class);
//		ModelAndView mav = new ModelAndView();
//		mav.setViewName("review/writeForm");
//		return mav;
//	}
	
	@RequestMapping(value = "/review/writeOk", method = RequestMethod.POST)
	public ModelAndView writeOk(ReviewVO vo, HttpServletRequest req) throws Exception {
		String savedName = uploadFile(vo.getRev_img().getOriginalFilename(), vo.getRev_img().getBytes());
		vo.setImage_url(savedName);
		ReviewDAO dao = sqlSession.getMapper(ReviewDAO.class);
		int cnt = dao.reviewInsert(vo);
		ModelAndView mav = new ModelAndView();
		if (cnt > 0) {
			mav.setViewName("redirect:/review/list");
		} else {
			mav.setViewName("redirect:writeForm");
		}
		return mav;
	}
	
	@RequestMapping("/review/edit")
	public ModelAndView board_eidtForm(@RequestParam("rev_no") int rev_no) {
		ReviewDAO dao = sqlSession.getMapper(ReviewDAO.class);
		ModelAndView mav = new ModelAndView();
		mav.addObject("vo", dao.reviewSelect(rev_no));
		mav.setViewName("review/editForm");
		return mav;
	}
	
//	@RequestMapping(value = "/review/writeOk", method = RequestMethod.POST)
//	public ModelAndView writeOk(ReviewVO vo, HttpServletRequest req, MultipartHttpServletRequest request) throws Exception {
//		HttpSession session = req.getSession();
//		String logid = (String) session.getAttribute("logid");
//		ReviewDAO dao = sqlSession.getMapper(ReviewDAO.class);
//		MultipartFile uploadFile = vo.getUploadFile();
//		
//		System.out.println("writeOk????????????"+uploadFile.toString());
//		int cnt = dao.reviewInsert(vo);
//		int rev_no = dao.getNewRevNo(Integer.parseInt(session.getAttribute("mem_no").toString()));
//		
//		ImguploadVO imgVo = new ImguploadVO();
//		imgVo.setRev_no(rev_no);
//		String fileName = this.imgUpload(req, request, uploadFile, imgVo,"insert");
//		System.out.println("revNo??????????????"+rev_no);
//		System.out.println("fileName??????????????"+fileName);
//		ModelAndView mav = new ModelAndView();
//		if (cnt > 0) {
//			mav.addObject("rev_no",rev_no);
//			mav.setViewName("redirect:/review/detail");
//		} else {
//			mav.setViewName("redirect:writeForm");
//		}
//		return mav;
//	}

	

//	@RequestMapping("/review/edit")
//	public ModelAndView board_eidtForm(@RequestParam("rev_no") int rev_no,ReviewVO vo,HttpServletRequest req) throws Exception {
//		// HttpSession session = req.getSession();
//		ReviewDAO dao = sqlSession.getMapper(ReviewDAO.class);
//		System.out.println("reviewEdite rev_no????????"+rev_no);
//		path = req.getSession().getServletContext().getRealPath("/imgUpload");
//		String fileName = dao.getFile(rev_no).getFile_name();
//		int imgNo = dao.getFile(rev_no).getImg_no();
//		
//		ModelAndView mav = new ModelAndView();
//		mav.addObject("vo", dao.reviewSelect(rev_no));
//		mav.addObject("rev_no", vo.getRev_no());
//		if(fileName != null) {
//			mav.addObject("fileName", fileName);
//			mav.addObject("imgNo", imgNo);
//			mav.addObject("path", path);
//		}else {
//			mav.addObject("fileName", "");
//		}
//		mav.setViewName("review/editForm");
//		return mav;
//	}

//	@RequestMapping(value = "/review/editOk", method = RequestMethod.POST)
//	public ModelAndView boardEditOk(ReviewVO vo, HttpServletRequest req, MultipartHttpServletRequest request, @RequestParam("img_no") int img_no) throws Exception {
//		HttpSession session = req.getSession();	
//		String logid = (String) session.getAttribute("logid");
//		ReviewDAO dao = sqlSession.getMapper(ReviewDAO.class);
//		
//		MultipartFile uploadFile = vo.getUploadFile();
//		
//		System.out.println("editOk????????????"+uploadFile.toString());
//		int cnt = dao.reviewUpdate(vo);
//
//		new File(path + vo.getUploadFile().getOriginalFilename()).delete();
//		
//		ImguploadVO imgVo = new ImguploadVO();
//		imgVo.setRev_no(vo.getRev_no());
//		imgVo.setImg_no(img_no);
//		String fileName = this.imgUpload(req, request, uploadFile, imgVo,"update");
//		System.out.println("editOk revNo??????????????"+vo.getRev_no());
//		System.out.println("editOk img_no??????????????"+img_no);
//		System.out.println("editOk fileName??????????????"+fileName);
//		
//		ModelAndView mav = new ModelAndView();
//		if (cnt > 0) {			
//			mav.addObject("rev_no", vo.getRev_no());	
//			mav.setViewName("redirect:/review/detail");
//		} else {
//			mav.setViewName("redirect:writeForm");
//		}
//		return mav;
//	}

	@RequestMapping("/review/delOk")
	public ModelAndView boardDelOk(ReviewVO vo , @RequestParam("rev_no") int rev_no) throws Exception {
		ReviewDAO dao = sqlSession.getMapper(ReviewDAO.class);
		 dao.deleteImg(rev_no);
		int cnt = dao.reviewDelete(vo);
		//dao.updatehit(rev_no);
		
		System.out.println(rev_no);
		ModelAndView mav = new ModelAndView();
		mav.addObject("rev_no", vo.getRev_no());
		mav.addObject("vo", vo);
		mav.setViewName("redirect:/review/list");
		return mav;
	}

//	@Transactional
//	public String imgUpload(HttpServletRequest req, MultipartHttpServletRequest request, MultipartFile uploadFile, ImguploadVO imgVo, String method) {
//		System.out.println("img 백앤드 시작");
//		String fileName = "";
//        OutputStream out = null;
//        PrintWriter printWriter = null;
//		try {
//			System.out.println("imgUpload????????????"+uploadFile.toString());			
//			path = req.getSession().getServletContext().getRealPath("/imgUpload/");
//			System.out.println("img 백앤드2222222222" + path);
//
////	  ImguploadVO vo = new ImguploadVO(); 
//
//
//			fileName = uploadFile.getOriginalFilename();
//            byte[] bytes = uploadFile.getBytes();
//
//            File file = new File(path);
//
//            // 파일명이 중복체크
//            if (fileName != null && !fileName.equals("")) {
//                if (file.exists()) {
//            // 파일명 앞에 구분(예)업로드 시간 초 단위)을 주어 파일명 중복을 방지한다.
//                fileName = System.currentTimeMillis() + "_" + fileName;
//                file = new File(path + fileName);
//                }
//            }
//            out = new FileOutputStream(file);
//
//            out.write(bytes);
//
////            ImguploadVO imgVo = new ImguploadVO();
//            imgVo.setFile_name(fileName);
//            imgVo.setFile_path(path);
////            imgVo.setRev_no(rev_no);
////            imgVo.setImg_no(imgNo);
//		     // 해당 경로만 받아 db에 저장한다.
//            System.out.println("imgUpload ImguploadVO ??????????????"+imgVo.toString());
//		     ReviewDAO dao = sqlSession.getMapper(ReviewDAO.class);
//		     int result = 0;
//		     if(method.equals("insert")) {
//		    	 System.out.println("imgUpload insert????????????");
//		    	 result = dao.insertImg(imgVo);		 
//		    	 System.out.println("fileUpload insert!!!!!!!!!!!");
//		     }else if(method.equals("update")){
//		    	 System.out.println("imgUpload update \nimgVo????????????fileName?"+imgVo.getFile_name()+"\nimNo???"+imgVo.getImg_no()+"\nrev_no?????"+imgVo.getRev_no());
//		    	 result = dao.updateImg(imgVo);
//		    	 System.out.println("fileUpload update!!!!!!!!!!!");
//		     }
//		     System.out.println("fileUpload result??????????"+result);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		return fileName;
//
//	}

}
