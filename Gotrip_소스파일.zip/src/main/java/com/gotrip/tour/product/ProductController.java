package com.gotrip.tour.product;

import java.util.List;
import java.util.Map;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.multipart.MultipartFile;

import com.gotrip.tour.product.ProductDAO;
import com.gotrip.tour.product.ProductVO;

import com.gotrip.tour.util.MediaUtils;
import com.gotrip.tour.util.UploadFileUtils;

@Controller
public class ProductController {
//	http://localhost:9000/Gotrip/review/list
	@Autowired
	SqlSession sqlSession;

	
	@Resource(name = "uploadPath")
	private String uploadPath;
	
	// reviewDAO안씀ㅜㅜ Map으로 돌림ㅜㅜ DAO 공부하기ㅠㅠ review.xml에서 바로 받음
	// GetMapping(value="/파일이름/jsp이름")
	@GetMapping(value = "/product/list")
	public ModelAndView view(@RequestParam Map<String, Object> pMap) {
		List<Map<String, Object>> lst = null;
		lst = sqlSession.selectList("getAllProRecord", pMap);
		ModelAndView mav = new ModelAndView();
		mav.addObject("lst", lst);
		mav.setViewName("product/product");
		System.out.println(lst);
		return mav;
	}
	
	@GetMapping(value = "/product/listkor")
	public ModelAndView viewkor(@RequestParam Map<String, Object> pMap) {
		List<Map<String, Object>> lst = null;
		lst = sqlSession.selectList("getAllProRecordKor", pMap);
		ModelAndView mav = new ModelAndView();
		mav.addObject("lst", lst);
		mav.setViewName("product/productkor");
		System.out.println(lst);
		return mav;
	}
	
	@GetMapping(value = "/product/listforeign")
	public ModelAndView viewforeign(@RequestParam Map<String, Object> pMap) {
		List<Map<String, Object>> lst = null;
		lst = sqlSession.selectList("getAllProRecordForeign", pMap);
		ModelAndView mav = new ModelAndView();
		mav.addObject("lst", lst);
		mav.setViewName("product/productforeign");
		System.out.println(lst);
		return mav;
	}

	// reviewDAO안씀ㅜㅜ Map으로 돌림ㅜㅜ DAO 공부하기ㅠㅠ
	@GetMapping(value = "/product/detail")
	public ModelAndView view2(@RequestParam Map<String, Object> pMap, @RequestParam("pro_no") int pro_no, ProductVO vo,
			HttpServletRequest req) throws Exception {

		List<Map<String, Object>> lst = null;
		ProductDAO dao = sqlSession.getMapper(ProductDAO.class);
		lst = sqlSession.selectList("getAllProRecord2", pMap);
		ModelAndView mav = new ModelAndView();
		mav.addObject("lst", lst);
		mav.addObject("pro_no", pro_no);
		mav.setViewName("product/productdetail");

		return mav;
	}

	@RequestMapping("/product/write")
	public ModelAndView board_writeForm() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("product/writeForm");

		return mav;
	}

	private String uploadFile(String originalName, byte[] fileDate) throws IOException {

		UUID uid = UUID.randomUUID();

		String savedName = uid.toString() + "_" + originalName;
		File target = new File(uploadPath, savedName);

		// org.springframework.util 패키지의 FileCopyUtils는 파일 데이터를 파일로 처리하거나, 복사하는 등의 기능이
		// 있다.
		FileCopyUtils.copy(fileDate, target);

		return savedName;

	}

	// 제출전에 POST로 바꾸기!! review DAO로 넘겨받음 -> map을 int로 받기위해서 중간역할 필요함 (Logic이 없어서
	// DAO로 중간역할함)
	@RequestMapping(value = "/product/writeOk", method = RequestMethod.POST)
	public ModelAndView writeOk(ProductVO vo, HttpServletRequest req) throws Exception {
		String savedName = uploadFile(vo.getPro_img().getOriginalFilename(), vo.getPro_img().getBytes());
		vo.setImage_url(savedName);
		ProductDAO dao = sqlSession.getMapper(ProductDAO.class);
		int cnt = dao.productInsert(vo);
		ModelAndView mav = new ModelAndView();
		if (cnt > 0) {
			mav.setViewName("redirect:/product/list");
		} else {
			mav.setViewName("redirect:writeForm");
		}
		return mav;
	}

	/*
	 * @ResponseBody public String idCheck(@RequestParam("mem_id") String mem_id) {
	 * // System.out.println(userId); String lst = sqlSession.selectOne("idCheck");
	 * return "redirect:writeForm"; }
	 */
	@RequestMapping("/product/edit")
	public ModelAndView board_eidtForm(@RequestParam("pro_no") int pro_no) {
		ProductDAO dao = sqlSession.getMapper(ProductDAO.class);
		ModelAndView mav = new ModelAndView();
		mav.addObject("vo", dao.productSelect(pro_no));
		mav.setViewName("product/editForm");
		return mav;
	}

	@RequestMapping(value = "/product/editOk", method = RequestMethod.POST)
	public ModelAndView boardEditOk(ProductVO vo) {
		ProductDAO dao = sqlSession.getMapper(ProductDAO.class);
		int cnt = dao.productUpdate(vo);
		ModelAndView mav = new ModelAndView();
		mav.addObject("pro_no", vo.getPro_no());
		if (cnt > 0) { // if succeed
			mav.addObject("vo", vo);
			mav.setViewName("redirect:/product/list");
		} else {
			mav.setViewName("redirect:writeForm");
		}
		return mav;
	}

}
