package com.gotrip.tour.product;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

public class ProductVO {
	private int pro_no;
	private String pro_title;
	private String pro_type;
	private int pro_price;
	private String pro_detail;
	private int pro_date;
	private String pro_area;
	private int pro_hit;
	private int pro_start;
	private int pro_end;
	private int pro_state;
	private int pro_like;
	private MultipartFile pro_img;
	private String image_url;

	public int getPro_no() {
		return pro_no;
	}

	public void setPro_no(int pro_no) {
		this.pro_no = pro_no;
	}

	public String getPro_title() {
		return pro_title;
	}

	public void setPro_title(String pro_title) {
		this.pro_title = pro_title;
	}

	public String getPro_type() {
		return pro_type;
	}

	public void setPro_type(String pro_type) {
		this.pro_type = pro_type;
	}

	public int getPro_price() {
		return pro_price;
	}

	public void setPro_price(int pro_price) {
		this.pro_price = pro_price;
	}

	public String getPro_detail() {
		return pro_detail;
	}

	public void setPro_detail(String pro_detail) {
		this.pro_detail = pro_detail;
	}

	public int getPro_date() {
		return pro_date;
	}

	public void setPro_date(int pro_date) {
		this.pro_date = pro_date;
	}

	public String getPro_area() {
		return pro_area;
	}

	public void setPro_area(String pro_area) {
		this.pro_area = pro_area;
	}

	public int getPro_hit() {
		return pro_hit;
	}

	public void setPro_hit(int pro_hit) {
		this.pro_hit = pro_hit;
	}

	public int getPro_start() {
//		SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-DD");
//
//		return sdf.format(new Date(pro_start));
		return pro_start;
	}

	public void setPro_start(int pro_start) {
//		SimpleDateFormat startDateSdf = new SimpleDateFormat("YYYY-MM-DD");
//		Date dt;
//		try {
//			dt = startDateSdf.parse(pro_start);
//			long epoch = dt.getTime();
//			this.pro_start = (int) (epoch / 1000);
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		this.pro_start = pro_start;

	}

	public int getPro_end() {
//		SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-DD");
//
//		return sdf.format(new Date(pro_end));
		return pro_end;
	}

	public void setPro_end(int pro_end) {
//		SimpleDateFormat startDateSdf = new SimpleDateFormat("YYYY-MM-DD");
//		Date dt;
//		try {
//			dt = startDateSdf.parse(pro_end);
//			long epoch = dt.getTime();
//			this.pro_end = (int) (epoch / 1000);
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		this.pro_end = pro_end;
	}

	public int getPro_state() {
		return pro_state;
	}

	public void setPro_state(int pro_state) {
		this.pro_state = pro_state;
	}

	public int getPro_like() {
		return pro_like;
	}

	public void setPro_like(int pro_like) {
		this.pro_like = pro_like;
	}

	public MultipartFile getPro_img() {
		return pro_img;
	}

	public void setPro_img(MultipartFile pro_img) {
		this.pro_img = pro_img;
	}

	public String getImage_url() {
		return image_url;
	}

	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}
}
