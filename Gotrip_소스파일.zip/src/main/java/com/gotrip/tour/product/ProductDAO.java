package com.gotrip.tour.product;

import java.util.List;
import java.util.Map;

import com.gotrip.tour.product.ProductVO;
import com.gotrip.tour.review.ReviewVO;

public interface ProductDAO {
	
	   //xml-> DAO-> VO-> Controller -> jsp 순서대로 데이터 이동함   
	    public int commentCount() throws Exception;
	 
	   public List<ProductVO> getAllProRecord(ProductVO vo); //리뷰 리스트  review.xml로 받았음
	   
	   public List<ProductVO> getAllProRecordKor(ProductVO vo); //리뷰 리스트  review.xml로 받았음

	   public List<ProductVO> getAllProRecordForeign(ProductVO vo); //리뷰 리스트  review.xml로 받았음
	   
	   public List<ProductVO> getAllProRecord2(Map<String,Object> pMap); // 리뷰상세보기 review.xml로 받았음
	   
	   public int productInsert(ProductVO vo) throws Exception; // 리뷰쓰기
	 
		public ProductVO productSelect(int pro_no);
			
		public int productUpdate(ProductVO vo);
				
		public int productDelete(ProductVO vo);
	   
}
